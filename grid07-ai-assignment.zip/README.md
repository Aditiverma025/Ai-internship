# Grid07 AI Assignment

## Overview
This project implements:
- Vector-based routing (FAISS)
- LangGraph content engine
- RAG with prompt injection defense

## How to Run
1. Install dependencies:
pip install -r requirements.txt

2. Add your API key in .env

3. Run:
python main.py

## Phases
- Phase 1: Persona routing
- Phase 2: Content generation
- Phase 3: Defense with RAG
